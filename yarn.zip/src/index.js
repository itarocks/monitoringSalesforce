const express = require('express')
const path = require('path')
const nunjucks =  require('nunjucks')
const app = express();

var filas = "";

const testes = ['Itamar'];

app.use(express.urlencoded({
  extended:false
}))


nunjucks.configure('views',{
  autoescape:true,
  express:app,
  watch: true
})

app.use(express.static(path.resolve(__dirname,'public')))
app.set('view engine', 'njk')


app.get('/', (req,res) => {
  console.log('entrou');
  const https = require("https");
  const request = require("request");
  const url =
    "https://test.salesforce.com/services/oauth2/token?grant_type=password&username=siglatv@userede.com.br.preprod&password=Forca010203Dn2FoFWpFevb0SclBgz0KmITI&client_id=3MVG9Nc1qcZ7BbZ0Ep18pfQsltaXFhVpiSQRGrk5W_UrMBOlQ9ZUe1iF6M50Qanx3JvRzqGSfibiYWvzsYGK7&client_secret=8061199631491967079";
  
  var token = "";
  
  var options = {
    method: "post",
    // body: postData, // Javascript object
    json: true, // Use,If you are sending JSON data
    url: url,
    headers: {
      // Specify headers, If any
    }
  };
  
  const url2 =
    "https://userede--preprod.cs24.my.salesforce.com/services/data/v45.0/query?q=SELECT+Id+FROM+Queue__C+WHERE+CreatedDate+<+TODAY+Limit+10";
  
  request(options, function(err, res, body) {
    if (err) {
      console.log("Error :", err);
      return;
    }
    token = body.access_token;
   // console.log(" Body :", body);
  });
  
  var options2 = {
    method: "get",
    // body: postData, // Javascript object
    json: true, // Use,If you are sending JSON data
    url: url2,
    headers: {
      "Authorization":
        "Bearer 00D0t0000000zFR!ARkAQNY4DhM22KlSpNf_Ln.ykwhxLAkW5RTHH1sFXNjDGBspyQMiOdHURxLguUknBHP7bQDpFE5ZiTMM7efs.1nuKXQrrE9A",
        "Content-Type": "application/json"        
    }
  };
  
  request(options2, function(err, res, body) {
    if (err) {
      console.log("Error :", err);
      return;
    }
    filas = body.records;
   //console.log('o valor das filas' + filas.id)
    console.log(body);
  });
  return res.render('show',{ filas } );
})

app.listen(3000);





